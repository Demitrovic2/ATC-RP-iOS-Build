ATC RP iOS v0.7.0 — GitHub Build Pack

Upload these TWO paths to the root of your GitHub repo:
  ci/ATC-RP-iOS-v0.7.0-build-source.zip
  .github/workflows/ios-v07-build.yml

Push to branch: main

GitHub Actions will start automatically.
When green:
Actions -> Build ATC RP iOS v0.7.0 IPA -> latest run -> Artifacts
Download: ATC-RP-iOS-v0.7.0-unsigned
Inside: ATC-RP-iOS-v0.7.0-unsigned.ipa

Unsigned IPA must be signed for your iPhone using a sideload/signing method.
